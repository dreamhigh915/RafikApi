<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class exam_result extends Model
{
    public $table='exam_result';
}
