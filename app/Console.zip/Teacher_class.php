<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher_class extends Model
{
    public $table='teacher_class';
}
