<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Institution_branch extends Model
{
     public $table='institiution_branch';
}
