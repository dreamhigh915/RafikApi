<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class home extends Model
{
    public $table='home';
}
