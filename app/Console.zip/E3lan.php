<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class E3lan extends Authenticatable
{
        public $table = 'E3lan';

}