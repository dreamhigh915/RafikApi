<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class special_questionTye extends Model
{
    public $table='special_questiontype';
}
