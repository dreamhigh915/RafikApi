<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leveles extends Model
{
    public $table='levels';
}
