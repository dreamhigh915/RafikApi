<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shared_reports extends Model
{
    public $table='shared_reports';
}
