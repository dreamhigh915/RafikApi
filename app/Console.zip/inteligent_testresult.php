<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inteligent_testresult extends Model
{
    public $table='inteligent_testresult';
}
