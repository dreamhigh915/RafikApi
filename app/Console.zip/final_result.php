<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class final_result extends Model
{
    public $table='final_result';
}
