<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class conditions extends Model
{
   public $table='conditions';
}
