<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Test_answer extends Model
{
    public $table='test_answer';
}
