<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Copon extends Model
{
      public $table='copon';
}
