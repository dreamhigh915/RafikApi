<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Test_questions extends Model
{
      public $table='test_questions';
}
