<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trainer_Language extends Model
{
    public $table='trainer_language';
}
