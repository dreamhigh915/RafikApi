<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class test_reports extends Model
{
    public $table='test_reports';
}
