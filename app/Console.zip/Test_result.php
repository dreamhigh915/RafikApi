<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Test_result extends Model
{
     public $table='test_result';
}
