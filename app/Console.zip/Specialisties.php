<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Specialisties extends Model
{
    public $table='specialties';


    
}
