<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class parentChild_state extends Model
{
    public $table='parentChild_state';
}
