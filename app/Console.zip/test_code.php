<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class test_code extends Model
{
    public $table='test_code';
}
