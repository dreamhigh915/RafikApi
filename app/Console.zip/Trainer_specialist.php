<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trainer_specialist extends Model
{
    public $table='trainer_specialties';
}
