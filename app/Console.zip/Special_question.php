<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Special_question extends Model
{
    public $table='special_questions';
}
