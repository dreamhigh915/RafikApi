<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class admin_roles extends Model
{
    public $table='admin_roles';
}
