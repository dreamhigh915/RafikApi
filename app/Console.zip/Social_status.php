<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Social_status extends Model
{
    public $table='social_status';
}
